/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojo;

/**
 *
 * @author JDufo
 */
public class Place_Reservee {
    private Place place;
    private Panier panier;
    private int prix;

    public Place_Reservee(Place place, Panier panier, int prix) {
        this.place = place;
        this.panier = panier;
        this.prix = prix;
    }

    public Place getPlace() {
        return place;
    }

    public void setPlace(Place place) {
        this.place = place;
    }

    public Panier getPanier() {
        return panier;
    }

    public void setPanier(Panier panier) {
        this.panier = panier;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }
    
    
    @Override
    public String toString()
    {
        String placeRtoString = "";
        placeRtoString += "Place : "+this.place.getIdPlace()+"\n"+
                                    "Position : "+this.place.getPosition()+"\n"+
                                    "Classe : "+this.place.getClasse()+"\n"+
                                    "Prix : "+this.prix;
        return placeRtoString;
 }

    
    
}
